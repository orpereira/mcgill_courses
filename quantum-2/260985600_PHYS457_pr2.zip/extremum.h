#ifndef EXTREMUM_H
#define EXTREMUM_H

double Extremum_GetExtremum
    (double (*func)(double), double x_init, double *curvature);

#endif