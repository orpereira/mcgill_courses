#ifndef INIT_H
#define INIT_H
void Init_CalcScales(void);
    // Get the energy and length scales to prepare for solving the radial equation
#endif